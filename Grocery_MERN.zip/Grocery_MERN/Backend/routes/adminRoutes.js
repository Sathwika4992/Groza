
const controller=require("../Controllers/adminController");
const express=require("express");
const router= express.Router();

router.post("/admin-register",controller.adminRegister);
router.post("/admin-login",controller.adminLogin);
router.get("/show-admin",controller.getAdmins);  

module.exports=router