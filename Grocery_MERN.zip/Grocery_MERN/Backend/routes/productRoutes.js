const controller = require("../Controllers/productControllers");
const express = require("express");
const upload = require("../middleware/imageMiddleware")
const router = express.Router();

router.post("/add-product",upload.single("image"), controller.createProduct);
router.get("/show-products",controller.getProducts);  
router.delete("/delete-product/:id", controller.deleteProduct);



module.exports = router;
