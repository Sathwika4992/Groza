

const mongoose=require("mongoose")

const Category_Enum=[
    "Vegetables","Fruits","Food-grains"
]

const ProductSchema=new mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    desc:{
        type:String,
        required:true 
    },
    Price:{
        type:Number

    },
    Category:{
        type:String,
        values:Category_Enum
    },
    image:{
        type:String
    },
      unit:{
        type:String
      },
    isActive:{
        type:Boolean
    },
    
},{timestamps:true})

module.exports=mongoose.model("Product",ProductSchema)