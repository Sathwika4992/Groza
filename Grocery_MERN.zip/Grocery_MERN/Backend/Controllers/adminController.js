

const Admin=require("../Models/Admin")
const bcrypt=require("bcryptjs")
const jwt=require("jsonwebtoken")


exports.adminRegister=async(req,res)=>{
    try{

        const {Name,Email,Password}=req.body;
        const adminRecord= await Admin.findOne({Email});

        if (adminRecord){

            return res.status(400).json({msg:"Email already exists"});
        }

        const hashedPassword=await bcrypt.hash(Password,10);

        const admin=await Admin.create({
            Name,Email,Password:hashedPassword
        })

        return res.status(201).json({msg:"Admin registered successfully"})


       


    }catch(error){
        return res.status(500).json({msg:error.message})

    }
}

 exports.getAdmins=async(req,res)=>{
            try{
                const newAdmin=await Admin.find()
        
                return res.status(201).json({mess:"Success",newAdmin})
            }catch(error){
                console.error(error.message)
                
            }
        }

exports.adminLogin=async(req,res)=>{
    try{

        const {Email,Password}=req.body;

        const adminRecord= await Admin.findOne({Email});

        if (!adminRecord){
            res.status(401).json({msg:"Invalid Email.."})  
        }
        const adminPassword= await bcrypt.compare(Password, adminRecord.Password)

            if(!adminPassword){
                res.status(401).json({msg:"Invalid Password.."})
            }

            const token=jwt.sign(
                {adminId:adminRecord._id}, process.env.JWT_SECRET,{expiresIn:"1d"}

              
            )

              return res.status(200).json({msg:"Login Success",token})




    }catch{
        return res.status(500).json({msg:error.message})
    }
}