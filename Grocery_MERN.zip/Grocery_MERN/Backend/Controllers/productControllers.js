

const product =require("../Models/Product");

exports.createProduct= async(req,res)=>{
    try{
        const {name,desc,Price,Category,unit}=req.body
        
        const image= req.file? `/uploads/${req.file.filename}`: null

        const products=await product.create({
            name,desc,Price,Category,unit,image
        })

        return res.status(200).json({msg:"product added",products})


    } catch(error){
        console.error(error.message)
    }
}

exports.getProducts=async(req,res)=>{
    try{
        const newProducts=await product.find()

        return res.status(201).json({mess:"Success",newProducts})
    }catch(error){
        console.error(error.message)
        
    }
}
exports.deleteProduct = async (req, res) => {
    try {
        const { id } = req.params;

        const deletedProduct = await product.findByIdAndDelete(id);

        if (!deletedProduct) {
            return res.status(404).json({
                msg: "Product not found"
            });
        }

        return res.status(200).json({
            msg: "Product deleted successfully",
            deletedProduct
        });

    } catch (error) {
        console.error(error.message);
        return res.status(500).json({
            msg: "Error deleting product",
            error: error.message
        });
    }
};
